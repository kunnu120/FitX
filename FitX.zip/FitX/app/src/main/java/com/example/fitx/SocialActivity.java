package com.example.fitx;

public class SocialActivity {
}
